$('#san-francisco').click(function(){
	$('.container').append('<p class="visit-me">Come visit!</p>');
});

/*
 * My plan for the rest of my JavaScript

 1) When a user hovers over the image of my dog, switch the image to a new image of him
 2) When the user hovers on the image of a software engineer, open a tooltip with a link to my GitHub repos
 */