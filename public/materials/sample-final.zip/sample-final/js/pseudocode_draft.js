/*
 * My plan for my JavaScript

 1) When a user hovers over the image of my dog, switch the image to a new image of him
 2) When the user hovers on the image of a software engineer, open a tooltip with a link to my GitHub repos
 3) When the user clicks on the image of San Francisco, display some text that says "Come Visit!" below the images
 */