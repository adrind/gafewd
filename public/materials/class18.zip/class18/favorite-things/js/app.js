var favoriteThings = [
  {
    image: 'http://images.all-free-download.com/images/graphicthumb/cute_puppy_photo_picture_11_168839.jpg',
    text: 'Puppies!'
  },
  {
    image: 'http://images4.fanpop.com/image/photos/22400000/Cute-Kitten-kittens-22438020-480-360.jpg',
    text: 'Kittens!!'
  },
  {
    image: 'https://solidgeargroup.com/wp-content/uploads/2016/08/technology-1283624_770.jpg',
    text: 'JavaScript!!!'
  }
];
